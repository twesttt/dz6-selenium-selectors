#!/usr/bin/env python
from .MainPage import MainPage
from .ProductPage import ProductPage
from .Catalog import Catalog
from .SearchPage import SearchPage

