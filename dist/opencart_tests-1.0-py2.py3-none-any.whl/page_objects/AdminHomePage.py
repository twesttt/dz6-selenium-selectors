from .BasePage import BasePage
import logging


class AdminHomePage(BasePage):

    logger = logging.getLogger('AdminHomePage')
    logger.info("I am on Admin Home Page")

    """ТУТ БУДУТ ЛОКАТОРЫ"""
