from .AdminLoginPage import AdminLoginPage
from .AdminProductsPage import AdminProductsPage
from .EditProductPage import EditProductPage
from .AdminHomePage import AdminHomePage